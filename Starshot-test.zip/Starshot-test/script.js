<script>
  const mobileMenuToggle = document.getElementById("mobile-menu-toggle");
  const navbar = document.querySelector(".navbar");

  mobileMenuToggle.addEventListener("click", () => {
    navbar.classList.toggle("mobile");
  });
</script>
